import * as React from "react";
import { useState } from "react";
import { StyleSheet } from "react-nativescript";

export function Calculator() {
  const [display, setDisplay] = useState("0");
  const [equation, setEquation] = useState("");
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false);

  const handleNumber = (num: string) => {
    if (display === "0" || shouldResetDisplay) {
      setDisplay(num);
      setShouldResetDisplay(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (operator: string) => {
    setShouldResetDisplay(true);
    setEquation(display + " " + operator + " ");
  };

  const calculate = () => {
    try {
      const result = eval(equation + display);
      setDisplay(String(result));
      setEquation("");
    } catch (e) {
      setDisplay("Error");
    }
    setShouldResetDisplay(true);
  };

  const clear = () => {
    setDisplay("0");
    setEquation("");
    setShouldResetDisplay(false);
  };

  return (
    <flexboxLayout className="flex-1 bg-gray-900">
      <flexboxLayout className="flex-1 p-4">
        <label className="text-gray-500 text-right w-full">{equation}</label>
        <label className="text-white text-right text-4xl w-full mt-2">{display}</label>
      </flexboxLayout>
      
      <gridLayout rows="auto, auto, auto, auto, auto" columns="*, *, *, *" className="bg-gray-800 p-2">
        <button row="0" col="0" className="bg-gray-700 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => clear()}>C</button>
        <button row="0" col="1" className="bg-gray-700 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleOperator('/')}>/</button>
        <button row="0" col="2" className="bg-gray-700 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleOperator('*')}>×</button>
        <button row="0" col="3" className="bg-gray-700 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleOperator('-')}>-</button>
        
        <button row="1" col="0" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('7')}>7</button>
        <button row="1" col="1" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('8')}>8</button>
        <button row="1" col="2" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('9')}>9</button>
        <button row="1" col="3" className="bg-gray-700 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleOperator('+')}>+</button>
        
        <button row="2" col="0" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('4')}>4</button>
        <button row="2" col="1" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('5')}>5</button>
        <button row="2" col="2" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('6')}>6</button>
        <button row="3" col="0" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('1')}>1</button>
        <button row="3" col="1" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('2')}>2</button>
        <button row="3" col="2" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('3')}>3</button>
        
        <button row="4" col="0" colSpan="2" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('0')}>0</button>
        <button row="4" col="2" className="bg-gray-600 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => handleNumber('.')}>.</button>
        
        <button row="2" col="3" rowSpan="3" className="bg-green-500 text-white text-2xl p-4 m-1 rounded-lg" onTap={() => calculate()}>=</button>
      </gridLayout>
      
      <label className="text-gray-400 text-center p-4">Calc by Pratiksha</label>
    </flexboxLayout>
  );
}